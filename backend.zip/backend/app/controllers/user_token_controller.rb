class UserTokenController < Knock::AuthTokenController
end
