class HomeController < ApplicationController

end
