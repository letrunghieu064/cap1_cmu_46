module WardsHelper
end
